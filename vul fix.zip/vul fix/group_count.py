from dataclasses import asdict
from lib2to3.pgen2.pgen import DFAState
from pyecharts import options as opts
from pyecharts.charts import Bar
import xlrd
import os
import pandas as pd
from collections import Counter
from pyecharts.faker import Faker
from pyecharts.globals import ThemeType
from datetime import date, timedelta
import time
import datetime


def main():

    df['Last Opened Date'] = pd.to_datetime(df['Last Opened Date'])  # 转化日期格式
    DayAgo = (datetime.datetime.now() - datetime.timedelta(days=30)).date()  # 当前时间30天之前的日期
    otherStyleTime = DayAgo.strftime("%Y%m%d")  # 转换日期格式

    sum_High_count = df['Finding Owner - PITO (RP)']
    count = Counter(sum_High_count)
    dict_count = dict(count)
    Finding_Owner_list = dict_count.keys()
    print(dict_count)
    print(df[(df['Finding Owner - PITO (RP)'] == str('Cao, Henry\nLi, Jonny')) & (df['Disney Severity Rating'] == 'Disney-Critical')])

    # f_out = open('group_count.csv', 'a+', encoding='utf-8')
    # f_out.write("Finding_Owner" + '\t' + 'Finding_Owner_high' + '\t' + 'Finding_Owner_high_overdue' + '\t' + 'Finding_Owner_Critical' + '\t' + 'Finding_Owner_Critical_overdue' + '\n')
    # for Finding_Owner in Finding_Owner_list:
    #     Finding_Owner_high = df[(df['Finding Owner - PITO (RP)'] == str(Finding_Owner)) & (df['Disney Severity Rating'] == 'Disney-High')]
    #     Finding_Owner_high_overdue = df[(df['Finding Owner - PITO (RP)'] == Finding_Owner) & (df['Disney Severity Rating'] == 'Disney-High') & (df['Last Opened Date'] < pd.to_datetime(otherStyleTime))]
    #     Finding_Owner_Critical = df[(df['Finding Owner - PITO (RP)'] == Finding_Owner) & (df['Disney Severity Rating'] == 'Disney-Critical')]
    #     Finding_Owner_Critical_overdue = df[(df['Finding Owner - PITO (RP)'] == Finding_Owner) & (df['Disney Severity Rating'] == 'Disney-Critical') & (df['Last Opened Date'] < pd.to_datetime(otherStyleTime))]
    #     print(Finding_Owner_high_overdue.shape[0])
    #     with open('group_count.csv', 'a+', encoding='utf-8',) as f_out:
    #         f_out.write(str(Finding_Owner)+'\t'+str(Finding_Owner_high.shape[0])+'\t'+str(Finding_Owner_high_overdue.shape[0])+'\t'+str(Finding_Owner_Critical.shape[0])+'\t'+str(Finding_Owner_Critical_overdue.shape[0])+'\n')
    #         f_out.flush()
    #         f_out.close()


if __name__ == '__main__':

    df = pd.read_excel('Auto_Rep_9132022813PM.xlsx')
    main()