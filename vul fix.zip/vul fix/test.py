
import pandas as pd
import datetime


DayAgo = (datetime.datetime.now() - datetime.timedelta(days=30)).date()  # 当前时间30天之前的日期
otherStyleTime = DayAgo.strftime("%Y%m%d")  # 转换日期格式


df = pd.read_excel('Auto_Rep_9132022813PM.xlsx')
df['Last Opened Date'] = pd.to_datetime(df['Last Opened Date'])

this_week_date = ('2022-9-12', '2022-9-18')

this_week_count_High = df[(df['Disney Severity Rating'] == 'Disney-High') & (df['Last Opened Date'] < pd.to_datetime(this_week_date[1])) & (df['Last Opened Date'] > pd.to_datetime(this_week_date[0]))]

print(this_week_count_High)