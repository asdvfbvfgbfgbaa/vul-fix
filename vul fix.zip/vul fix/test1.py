from pyecharts import options as opts
from pyecharts.charts import Bar
import pandas as pd
from collections import Counter
import datetime
import re
from pyecharts.charts import Pie


def get_this_week():
    now_time = datetime.datetime.now()  # 获取当前时间
    day_num = now_time.isoweekday()  # 当前天是这周的第几天
    week_start = ((now_time - datetime.timedelta(days=day_num)) + datetime.timedelta(
        days=1)).date()  # 计算当前天所在周周一 格式为yyyy-MM-dd
    week_end = ((now_time - datetime.timedelta(days=day_num)) + datetime.timedelta(
        days=7)).date()  # 计算当前天所在周周天 格式为yyyy-MM-dd
    week_e = ((now_time - datetime.timedelta(days=day_num)) + datetime.timedelta(
        days=7))  # 计算当前天所在周周天 格式为yyyy-MM-dd 12:01:13.026315
    week_s = ((now_time - datetime.timedelta(days=day_num)) + datetime.timedelta(
        days=1))  # 计算当前天所在周周一 格式为yyyy-MM-dd 12:01:13.026315
    # while week_s <= week_e:  # 循环输出周一至周五的每天日期格式yyyy-MM-dd
    # print(week_s.date())
    # week_s = week_s + datetime.timedelta(days=1)
    create_time__range = (week_start.strftime('%Y%m%d')), week_end.strftime('%Y%m%d')
    return create_time__range


def this_week_detail():
    sum_High_count = df[df['Disney Severity Rating'] == 'Disney-High'].shape[0]
    sum_Critical_count = df[df['Disney Severity Rating'] == 'Disney-Critical'].shape[0]
    print("Sum High count is: " + str(sum_High_count) + "\nSum critical count is:  " + str(sum_Critical_count))

    df['Last Opened Date'] = pd.to_datetime(df['Last Opened Date'])
    this_week_date = get_this_week()
    # print(this_week_date)
    this_week_count_High = df[(df['Disney Severity Rating'] == 'Disney-High') & (
            df['Last Opened Date'] < pd.to_datetime(this_week_date[1])) & (
                                      df['Last Opened Date'] > pd.to_datetime(this_week_date[0]))]
    this_week_count_critical = df[(df['Disney Severity Rating'] == 'Disney-Critical') & (
            df['Last Opened Date'] < pd.to_datetime(this_week_date[1])) & (
                                          df['Last Opened Date'] > pd.to_datetime(this_week_date[0]))]
    # print("this_week_date is:"+str(this_week_date))
    print("this week High count is: " + str(this_week_count_High.shape[0]) + "\nthis week critical count is:  " + str(
        this_week_count_critical.shape[0]))

    last_week_date_1 = datetime.datetime.strptime(this_week_date[0], "%Y%m%d") - datetime.timedelta(days=7)
    last_week_date_2 = datetime.datetime.strptime(this_week_date[1], "%Y%m%d") - datetime.timedelta(days=7)

    # print(last_week_date_1.strftime('%Y%m%d'), last_week_date_2.strftime('%Y%m%d'))

    last_week_count_High = df[(df['Disney Severity Rating'] == 'Disney-High') & (df['Last Opened Date'] < pd.to_datetime(last_week_date_2)) & (df['Last Opened Date'] > pd.to_datetime(last_week_date_1))]
    last_week_count_critical = df[(df['Disney Severity Rating'] == 'Disney-Critical') & (df['Last Opened Date'] < pd.to_datetime(last_week_date_2)) & (df['Last Opened Date'] > pd.to_datetime(last_week_date_1))]

    print("last week High count is: " + str(last_week_count_High.shape[0]) + "\nlast week critical count is:  " + str(
        last_week_count_critical.shape[0]))

    sum_detail_dict = {'sum_High_count': sum_High_count, 'sum_Critical_count': sum_Critical_count,
                       'this_week_count_High': this_week_count_High.shape[0],
                       'this_week_count_critical': this_week_count_critical.shape[0],
                       'last_week_count_High': last_week_count_High.shape[0],
                       'last_week_count_critical': last_week_count_critical.shape[0]}
    print(dict(sum_detail_dict))

    High_count_list = sum_detail_dict['sum_High_count'], sum_detail_dict['this_week_count_High'], sum_detail_dict[
        'last_week_count_High']
    Critical_count_list = sum_detail_dict['sum_Critical_count'], sum_detail_dict['this_week_count_critical'], \
                          sum_detail_dict['last_week_count_critical']

    c = (
        Bar()
            .add_xaxis(list(['Total', 'This week', 'Last week']))
            .add_yaxis("Critical Vulnerability Count", list(Critical_count_list))
            .add_yaxis("High Vulnerability Count", list(High_count_list))

            .set_global_opts(
            yaxis_opts=opts.AxisOpts(name="数量"),
            xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=-15)),
            title_opts=opts.TitleOpts(title="Disney Severity Rating Count", subtitle="漏洞评级统计"),
        )
            .render("this_week_detail.html")

    )


def overdue():

    df['Last Opened Date'] = pd.to_datetime(df['Last Opened Date'])  # 转化日期格式
    DayAgo = (datetime.datetime.now() - datetime.timedelta(days=30)).date()  # 当前时间30天之前的日期
    otherStyleTime = DayAgo.strftime("%Y%m%d")  # 转换日期格式
    overdue_Disney_High = df[(df['Disney Severity Rating'] == 'Disney-High') & (df['Last Opened Date'] < pd.to_datetime(otherStyleTime))]
    overdue_Disney_critical = df[(df['Disney Severity Rating'] == 'Disney-Critical') & (df['Last Opened Date'] < pd.to_datetime(otherStyleTime))]
    print("overdue (30 day) Disney-High count is : " + str(
        overdue_Disney_High.shape[0]) + " \noverdue (30 day) Disney-Critical count is : " + str(
        overdue_Disney_critical.shape[0]))


def critical_top5_app():

    app_owner_ciritical = df['Disney Severity Rating'] == 'Disney-Critical'
    sum_High_count = df['Business Applications'][app_owner_ciritical]
    count = Counter(sum_High_count)
    dict_count = dict(count)
    top_5 = sorted(dict_count.items(), key=lambda x: -x[1])  # 根据字典的value排序
    print(top_5[:5])
    critical_top5_app_dict = dict(top_5[:5])
    Pie_radius('critical top5 app', critical_top5_app_dict)


def app_owner_ciritical_top5():
    app_owner_ciritical = df['Disney Severity Rating'] == 'Disney-Critical'
    sum_High_count = df['Finding Owner - PITO (RP)'][app_owner_ciritical]
    count = Counter(sum_High_count)
    dict_count = dict(count)
    top = sorted(dict_count.items(), key=lambda x: -x[1])
    print(dict(top[:5]))
    top_5_dict = dict(top[:5])
    Pie_radius('Ciritical App Owner Ciritical Top5', top_5_dict)


def ciritical_keyword_top5():

    app_owner_ciritical = df['Disney Severity Rating'] == 'Disney-Critical'
    sum_High_count = df['Finding Short Description'][app_owner_ciritical]
    all_Finding_Short_Description = dict(sum_High_count).values()
    f_out = open('Finding_Short_Description.txt', 'w', encoding='utf-8')

    for iii in all_Finding_Short_Description:
        f_out.write(iii + ' ')
        f_out.flush()

    word = open('Finding_Short_Description.txt', 'r').read()

    str = re.sub(r"[^a-zA-Z]+", " ", word)
    # print("过滤后的字符串：", str)
    # 拆分成列表
    str = str.split(" ")
    # 去除多余的空项
    str.remove("")
    # print("拆分成列表：", str)
    # 生成字典的key列表
    dict_keys = []
    for i in str:
        if i not in dict_keys:
            dict_keys.append(i)
    # print("key列表：", dict_keys)
    # 输出字典

    # 定义空字典
    words_dict = {}

    # 往字典写入key值
    words_dict.fromkeys(dict_keys)

    # 遍历key列表,利用count函数统计单词出现次数 > words_dict
    for j in dict_keys:
        words_dict[j] = str.count(j)
    # 根据字典的value排序
    top = sorted(words_dict.items(), key=lambda x: -x[1])

    print("字典：", words_dict)

    print(top[:10])
    ciritical_keyword_top5_dict = dict(top[:10])
    Pie_radius('Ciritical Keyword Top5 Dict', ciritical_keyword_top5_dict)


def Pie_rich_label(title_str, dict_obj):
    c = (
        Pie()
            .add(
            "",
            [list(z) for z in zip(dict_obj.keys(), dict_obj.values())],
            radius=["20%", "55%"],
            label_opts=opts.LabelOpts(
                position="outside",
                formatter="{a|{a}}{abg|}\n{hr|}\n {b|{b}: }{c}  {per|{d}%}  ",
                background_color="#eee",
                border_color="#aaa",
                border_width=1,
                border_radius=4,
                rich={
                    "a": {"color": "#999", "lineHeight": 22, "align": "center"},
                    "abg": {
                        "backgroundColor": "#e3e3e3",
                        "width": "100%",
                        "align": "right",
                        "height": 22,
                        "borderRadius": [4, 4, 0, 0],
                    },
                    "hr": {
                        "borderColor": "#aaa",
                        "width": "100%",
                        "borderWidth": 0.5,
                        "height": 0,
                    },
                    "b": {"fontSize": 16, "lineHeight": 33},
                    "per": {
                        "color": "#eee",
                        "backgroundColor": "#334455",
                        "padding": [2, 4],
                        "borderRadius": 2,
                    },
                },
            ),
        )
            .set_global_opts(title_opts=opts.TitleOpts(title=title_str))
            .render(str(title_str + ".html"))
    )


def Pie_radius(title_str, dict_obj):
    c = (
        Pie()
            .add(
            "",
            [list(z) for z in zip(dict_obj.keys(), dict_obj.values())],
            radius=["40%", "75%"],
        )
            .set_global_opts(
            title_opts=opts.TitleOpts(title=title_str),
            legend_opts=opts.LegendOpts(orient="vertical", pos_top="15%", pos_left="2%"),
        )
            .set_series_opts(label_opts=opts.LabelOpts(formatter="{b}: {c}"))
            .render(str(title_str + ".html"))
    )


if __name__ == '__main__':

    df = pd.read_excel('Auto_Rep_9132022813PM.xlsx')
    this_week_detail()
    overdue()
    critical_top5_app()
    app_owner_ciritical_top5()
    critical_top5_app()
    ciritical_keyword_top5()
